package componentesGraficos;

import Permanentes.Mascota;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.util.Objects;

public class EscenaMascota extends StackPane {
    private final Image fondo;
    private final Image pouImage;
    private final ImageView fondoView;
    private final ImageView pouView;
    private final ColorAdjust colorAdjust;
    private int estadoTiempo; // 0 para noche, otro valor para día

    public EscenaMascota() {
        fondo = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/background1.jpg")));
        pouImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/pou.png")));

        fondoView = new ImageView(fondo);
        fondoView.setFitHeight(600);
        fondoView.setFitWidth(600);

        pouView = new ImageView(pouImage);
        pouView.setFitHeight(200);
        pouView.setFitWidth(200);
        pouView.setTranslateY(150);

        colorAdjust = new ColorAdjust();
        fondoView.setEffect(colorAdjust);

        getChildren().addAll(fondoView, pouView);
        estadoTiempo = 1; // Por defecto, día
    }

    private Timeline innerTimeline; // Declarar una referencia al Timeline interno

    public void apagarLuz() {
        if (estadoTiempo == 1) { // Si es de día
            estadoTiempo = 0;// Cambiar a noche
            System.out.println("Durmiendo...");
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.ZERO, new KeyValue(colorAdjust.brightnessProperty(), 0)),
                    new KeyFrame(new Duration(1000), new KeyValue(colorAdjust.brightnessProperty(), -0.7))

            );

            // Incrementar energía, salud y felicidad cada 0.5 segundos mientras es de noche
            innerTimeline = new Timeline(
                    new KeyFrame(Duration.ZERO, e -> {
                        Mascota.getInstance().setEnergy(Mascota.getInstance().getEnergy() + 20);
                        Mascota.getInstance().setHealth(Mascota.getInstance().getHealth() + 2);
                        Mascota.getInstance().setHappiness(Mascota.getInstance().getHappiness() + 2);
                    }),
                    new KeyFrame(Duration.millis(500))
            );
            innerTimeline.setCycleCount(Timeline.INDEFINITE); // Hacer un bucle cuando sea de noche

            // Parar el bucle cuando encendamos la luz
            timeline.setOnFinished(event -> {
                innerTimeline.stop(); // Para el bucle interno cuando termina el Timeline principal
            });

            // Iniciar los Timelines
            timeline.play();
            innerTimeline.play();
        }
    }


    public void encenderLuz() { //Esto es netamente estetico
        if (estadoTiempo == 0) { // Si es de noche
            estadoTiempo = 1; // Cambiar a día
            System.out.print("... " + Mascota.getInstance().getName() + " ha dormido como tronco chaval a todo gas!!!");
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.ZERO, new KeyValue(colorAdjust.brightnessProperty(), -0.7)),
                    new KeyFrame(new Duration(1000), new KeyValue(colorAdjust.brightnessProperty(), 0))
            );
            timeline.play();
        }
    }

    public int getEstadoTiempo() {
        return estadoTiempo;
    }
}
