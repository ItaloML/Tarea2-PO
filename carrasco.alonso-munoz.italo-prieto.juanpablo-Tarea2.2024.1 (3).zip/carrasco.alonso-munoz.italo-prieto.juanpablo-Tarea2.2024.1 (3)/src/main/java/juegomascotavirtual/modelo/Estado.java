package juegomascotavirtual.modelo;

public enum Estado {
    Neutro,
    Feliz,
    Triste,
    Hambriento,
    Enojado,
    Cansado,
    Muerto
}
