Pou 2 - Juego de Mascota Virtual
Pou 2 es un juego de mascota virtual desarrollado en JavaFX donde puedes interactuar con tu propia mascota virtual. En el juego, tu mascota virtual envejece con el tiempo y tienes que cuidar de ella manteniendo su salud, energía y felicidad.

Características principales:
Interacción con la mascota: Puedes alimentar, dar medicamentos y jugar con tu mascota virtual.
Control de la salud, energía y felicidad: Mantén un ojo en los niveles de salud, energía y felicidad de tu mascota.
Sistema de inventario: Guarda y gestiona los objetos que tienes para interactuar con tu mascota.
Visión en tiempo real: Observa cómo tu mascota envejece y responde a tus interacciones.
Requisitos previos
Para ejecutar el juego, necesitas tener instalado:

Java Runtime Environment (JRE) 8 o superior.
Un archivo de configuración (por ejemplo, config.csv) que contenga los detalles de tu mascota y su inventario.
Cómo ejecutar el juego
Clona este repositorio en tu máquina local.

Asegúrate de tener el archivo de configuración (config.csv) en la misma carpeta que el archivo ejecutable del juego.









