package juegomascotavirtual.controlador;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import juegomascotavirtual.modelo.*;
import juegomascotavirtual.vista.MenuGC;
import juegomascotavirtual.vista.View;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;

import java.util.ArrayList;
import java.util.Scanner;



public class Controlador {
    ArrayList<Item>inventarioOriginal = new ArrayList<Item>();
    private Mascota mascota;
    private View view;
    private final Timeline time;


    public Controlador(Scanner in) {
        readConfiguration(in);
        view = new View(mascota.getName(),mascota.getState());
        double INTERVAL = 0.5;
        time = new Timeline(new KeyFrame(Duration.seconds(INTERVAL), event-> {
            mascota.GetOld();
        }));
        time.setCycleCount(Timeline.INDEFINITE);
        time.play();
        time.pause();
        view.getInventario().intializeInventarioGC(inventarioOriginal);
        attachItemsEventHandlers();
        bindPetProperties();
        attachMenuEventHandlers();
    }

    private void updatePetState() {
        view.getPanelDeEstado().updateState(mascota);
    }

    private void readConfiguration(Scanner in) {
        // Creación de mascota
        String nombre_mascota = in.nextLine();
        this.mascota = new Mascota(nombre_mascota);

        // Llenando del inventario de la mascota
        while (in.hasNextLine()) {
            String linea = in.nextLine();
            String[] item_csv = linea.split(";");
            int id = Integer.parseInt(item_csv[0]);
            String tipoItem = item_csv[1];
            String nombreItem = item_csv[2];
            if (tipoItem.equals("Juguete")) {
                String rutaImagen = "/" + item_csv[3];
                inventarioOriginal.add(new Juguete(nombreItem, id, rutaImagen));
            } else if (tipoItem.equals("Alimento")) {
                int cantidad = Integer.parseInt(item_csv[3]);
                inventarioOriginal.add(new Comida(nombreItem, id, cantidad));
            } else {
                int cantidad = Integer.parseInt(item_csv[3]);
                inventarioOriginal.add(new Medicina(nombreItem, id, cantidad));
            }
        }
    }


    public View getView() {
        return view;
    }

    private void restart() {
        time.pause();
        mascota.reset();
        view.getInventario().intializeInventarioGC(inventarioOriginal);
    }

    private void attachItemsEventHandlers() {
        view.getInventario().attachEventHandlers(mascota);
    }

    private void bindPetProperties() {
        view.getPanelDeEstado().getHappinessBar().progressProperty().bind(mascota.getHappiness().divide(100.0).asObject());
        view.getPanelDeEstado().getEnergyBar().progressProperty().bind(mascota.getEnergy().divide(100.0).asObject());
        view.getPanelDeEstado().getHealthBar().progressProperty().bind(mascota.getHealth().divide(100.0).asObject());
    }


    private void attachMenuEventHandlers() {
        MenuGC menu = view.getMenu();

        menu.getIniciar().setOnAction(event -> {
            if (time.getStatus() == Animation.Status.PAUSED) time.play();
        });

        menu.getSalir().setOnAction(event -> {
            System.exit(0);
        });

        menu.getApagarLuz().setOnAction(event->{
            view.getEscenaMascota().apagarLuz();
            mascota.setSleeping(true);
            view.getInventario().disableButtons();
        });

        menu.getEncenderLuz().setOnAction(event->{
            view.getEscenaMascota().encenderLuz();
            mascota.setSleeping(false);
            view.getInventario().enableButtons();
        });

        menu.getReiniciar().setOnAction(event -> restart());

        menu.getAcercaDe().setOnAction(event -> showAboutWindow());
    }

    private void showAboutWindow() {
        Stage aboutStage = new Stage();
        aboutStage.initModality(Modality.APPLICATION_MODAL);
        aboutStage.initStyle(StageStyle.UTILITY);
        aboutStage.setTitle("Acerca de");

        Label aboutLabel = new Label("¡Este es un juego donde puedes interactuar con tu mascota virtual!\n" +
                "Durante el paso del tiempo tu mascota envejecerá. Hay puntos de salud, energía y felicidad, y podrás interactuar con ella alimentándola, utilizando sus medicinas o haciendo que use sus juguetes.\n" +
                "También podrás ver el estado en que se encuentra, ya sea feliz o neutro y muchos más .\n" +
                "¡Recuerda que tu mascota también puede morir! Así que debes tener un buen cuidado.");

        Button closeButton = new Button("X");
        closeButton.setOnAction(event -> aboutStage.close());

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.getChildren().addAll(aboutLabel, closeButton);

        Scene scene = new Scene(layout);
        aboutStage.setScene(scene);
        aboutStage.setResizable(false);
        aboutStage.showAndWait();
    }

}
