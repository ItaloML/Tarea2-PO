package juegomascotavirtual.vista;

import juegomascotavirtual.modelo.Estado;
import juegomascotavirtual.modelo.Mascota;

import javafx.geometry.Pos;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class PanelDeEstado extends VBox {

    private final ProgressBar healthBar = createProgressBar();
    private final ProgressBar energyBar = createProgressBar();
    private final ProgressBar happinessBar = createProgressBar();
    private final Text estado = new Text();
    private final Text nameText = new Text();

    public PanelDeEstado(String name, Estado mascota) {
        AnchorPane datosMascota = new AnchorPane();

        nameText.setText("Nombre:\t\t" + name + "\n\nEdad:\t\t 0.0");
        nameText.setFont(Font.font("Arial", 20));
        datosMascota.getChildren().add(nameText);
        AnchorPane.setTopAnchor(nameText, 10.0);
        AnchorPane.setBottomAnchor(nameText, 10.0);
        AnchorPane.setLeftAnchor(nameText, 45.0);

        VBox panelAtributos = new VBox();
        panelAtributos.setPrefWidth(400);
        panelAtributos.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        panelAtributos.setAlignment(Pos.CENTER);

        Text healthTitle = new Text("\nSalud");
        healthTitle.setFont(Font.font("Arial", 24));
        healthTitle.setFill(Color.RED);

        Text energyTitle = new Text("\n\nEnergía");
        energyTitle.setFont(Font.font("Arial", 24));
        energyTitle.setFill(Color.GREEN);

        Text happinessTitle = new Text("\n\nFelicidad");
        happinessTitle.setFont(Font.font("Arial", 24));
        happinessTitle.setFill(Color.BLUE);

        healthBar.setProgress(50.0 / 100.0);
        energyBar.setProgress(50.0 / 100.0);
        happinessBar.setProgress(50.0 / 100.0);

        panelAtributos.getChildren().addAll(healthTitle, healthBar, energyTitle, energyBar, happinessTitle, happinessBar);

        VBox estadoMascota = new VBox();
        estadoMascota.setAlignment(Pos.CENTER);
        Text estadoTitulo = new Text("Estado\n\n\n");
        estadoTitulo.setFont(Font.font("Arial", 24));
        estado.setText(mascota.toString());
        estado.setFont(Font.font("Arial", 48));
        estadoMascota.getChildren().addAll(estadoTitulo, estado); // Aquí se agrega el Text del estado

        getChildren().addAll(datosMascota, panelAtributos, estadoMascota);
        setPrefWidth(400);
        setSpacing(25);
    }

    private ProgressBar createProgressBar() {
        ProgressBar pb = new ProgressBar();
        pb.setPrefSize(450, 45);
        return pb;
    }

    public void updateState(Mascota mascota) {
        estado.setText(mascota.determineState().toString());
    }

    public ProgressBar getEnergyBar() {
        return energyBar;
    }

    public ProgressBar getHappinessBar() {
        return happinessBar;
    }

    public ProgressBar getHealthBar() {
        return healthBar;
    }
}
