package com.example.juegomascotavirtual.Permanentes;

public enum Estado {
    Neutro,
    Feliz,
    Triste,
    Hambriento,
    Enojado,
    Cansado,
    Muerto
}
